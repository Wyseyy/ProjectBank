/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ToDoList;

import java.util.ArrayList;
import java.io.*;
import java.net.*;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Eoinw
 */
public class ServerProtocolx extends Variables {

    private static final int PORT = 1234;//port variable
    private static ArrayList<String> List = new ArrayList<>();//ArrayList to take in List elements

    public static void main(String[] args) throws IOException {//start main
        try {//start try
            ServerSocket Ssock = new ServerSocket(PORT);//new server socket 
            System.out.println("Searching for connection.");
            while (true) {//start while
                Socket ClientSsock = Ssock.accept();
                System.out.println("Connected to port!" + ClientSsock.getInetAddress());
                Handler CHandler = new Handler(ClientSsock);//new thread handler
                new Thread(CHandler).start();//start the thread
            }//end while
        }//end try
        catch (SocketException e) {
            e.printStackTrace();
            System.out.println("Unable to attach to port!");
        }//end catch      
    }

    class IncorrectActionException extends Exception {//class to run IncorrectActionException, unfortunately does not work
        public IncorrectActionException(String message) {
            super(message);
        }//end constructor
    }//end ckass

    public static class Handler implements Runnable {//handler class

        private static boolean isValidAction(String userInput) {//validAction boolean for IncorrectActionException
            boolean isValidAction = false;
            return isValidAction;
        }//end boolean
        private Socket ClientSsock = null;

        private Handler(Socket ClientSsock) {
            this.ClientSsock = ClientSsock;
        }//end handler construction
         public void performAction(String userInput) throws IncorrectActionException {
        if (!isValidAction(userInput)) {
            //throw new IncorrectActionException("Invalid action: " + userInput); 
        }//end if
         }//end void
        public synchronized void run() {//start run
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(ClientSsock.getInputStream()));//bufferedReader to take in information.
                PrintWriter out = new PrintWriter(ClientSsock.getOutputStream(), true);//printWriter to print out information
                String userInput;//String for users to input data
                while (true) {//start while
                    userInput = in.readLine();
                    String[] tasks = userInput.split(";");//method to set up the split for users to input data in a specific format
                    String message = tasks[0].trim();//[] methods used to confirm the amount of different words either side of the ; are allowed
                    System.out.println(message);
                    String date = tasks[1].trim();
                    System.out.println(userInput);
                    if (userInput == null) {
                        out.println("message sent was empty");
                    }//end if
                    if (tasks.length >= 2) {//if statement to set a limit on the ammount of lines the tasks can use
                        if (message.equals("add") && tasks.length == 3) {//add must equal 3 (add;date;task)
                            String task = tasks[2].trim();
                            List.add(date);
                            System.out.println(date + "was recieved");
                            out.println("Task " + task + " has been added " + List);//method to add an item to a list
                        } else if (message.equals("list") && tasks.length == 2) {//list must equal 2 (list;date)
                            if (!List.isEmpty()) {
                                for (int i = 0; i < List.size(); i++) {
                                    if (List.get(i).matches(date)) {
                                        out.println("Task for this date:" + List.get(i));//method to display items in the list on a specific date, does not work
                                        continue;
                                    }
                                }//end for
                            } else {
                                out.println("There are no tasks for the date" + date + "Please input valid date for task");//out statement to show there are no tasks in the list for that date
                            }//end else
                        } else if (message.equals("STOP")) {//else if to allow user to exit system by typing STOP
                            System.out.println("TERMINATE");
                        } else {
                            out.println("Invalid option, please enter a valid option.");//out statement that tells the user if they have entered an invalid option
                            break;
                        }//end else
                    }//end if
                }//end while

                out.println("Closing connection" + ClientSsock.getInetAddress() + "Goodbye");//out statement to end the connection with the user

            }//end try
            catch (IOException e) {//catch statement to catch IOException
                e.printStackTrace();
            }//end catch
        }//end run
    }//end Handler
}//end ServerProtocol

