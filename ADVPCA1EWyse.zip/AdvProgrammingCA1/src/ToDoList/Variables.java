/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ToDoList;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.util.ArrayList;

/**
 *
 * @author Eoinw
 */
public class Variables {
    public final int PORT = 1234;
    public DatagramSocket Socket;
    public ServerSocket Ssock;
    public ServerSocket ClientSsock;
    public DatagramPacket Packetin, Packetout;
    public  byte[] buffer;

    /**
     *
     */
    public InetAddress host; 
    public String lhost = "localhost";
    public String ToDoDescription;
    public String TList;
    public String date;
    public static int clientConnections = 0;
}
