/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ToDoList;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Eoinw
 */
public class ClientProtocolx extends Variables {
//this class is the client side applicaton, dealing with the user inputting the data and displaying the menu

    public static void main(String[] args) throws IOException {//start main
        Variables v = new Variables();
        Socket ClientSsock = new Socket(v.lhost, v.PORT);//Client sided socket with the localhost variable and PORT variable being called from Variables class
        try {
            PrintWriter out = new PrintWriter(ClientSsock.getOutputStream(), true);//PrintWriter out for printing out information from the server
            BufferedReader in = new BufferedReader(new InputStreamReader(ClientSsock.getInputStream()));//BufferedReader out to print out information.

            System.out.println("Connection Successful.");
            Scanner CScanner = new Scanner(System.in);//scanner to take in user input
            String userInput;

            while (true) {//while true to print out the menu
                System.out.println("\n Please add a task in the correct format");
                System.out.println("\n add;date;task description");
                System.out.println("\n list;list;date");
                System.out.println("Exit System: STOP");
                userInput = CScanner.nextLine();
                System.out.println(userInput);
                out.println(userInput);//out statement to print out the users input

                if (userInput.equalsIgnoreCase("STOP")) {//an equals ignorecase to stop the run if STOP is entered
                    break;
                }//end if
                String serverResponse = in.readLine();
                System.out.println("Server Response:" + serverResponse);//a sysout to get the response from the server
            }//end while
        }//end try
        catch (IOException e) {//catch statement to catch an IOException
            e.printStackTrace();
        }//end catch
    }//end main
}//end class
 
